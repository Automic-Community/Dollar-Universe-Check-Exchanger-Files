#!/bin/sh
#######################################################################
# Check if the exchanger file contains old entries                    #
#                                                                     #
# The exchanger files should not contain items older than the current #
# day. This script will check these 2 files and abort if these files  #
# contain old entries.                                                #
#                                                                     #
# Return code: 0: Everything OK                                       #
#              1: Old record found                                    #
#              2: Environment not loaded                              #
#######################################################################

# set -x

#######################################################################
# Init

RESEXE=0

# Init if DUAS5
if [ ! -z "$UXDIR_ROOT" ]
then
    FILE_CD=$UXDEX/u_fecd50.dta
    FILE_CL=$UXDEX/u_fecl50.dta

# Init if DUAS6
elif [ ! -z "$UNI_DIR_ROOT" ]
then
    FILE_CD=$UNI_DIR_ROOT/data/exp/u_fecd60.dta
    FILE_CL=$UNI_DIR_ROOT/data/exp/u_fecl60.dta

# DUAS Environnement not loaded
else 
    echo "ERROR: Dollar Universe environment not loaded"
    RESEXE=2
    exit 2
fi

# Get the important dates
DAT_TODAY=$(date +'%Y%m%d')
DAT_THISYEAR=$(date +'%Y')
DAT_LASTYEAR=`expr $DAT_THISYEAR - 1`




#######################################################################
# Main procedure


echo "Checking old entries in the echanger files"


# Check in fecd
NB_LINES=0
NB_LINES_T=`cat $FILE_CD | grep -av $DAT_TODAY | grep -a $DAT_THISYEAR | wc -l`
NB_LINES=`expr $NB_LINES + $NB_LINES_T`
NB_LINES_T=`cat $FILE_CD | grep -av $DAT_TODAY | grep -a $DAT_LASTYEAR | wc -l`
NB_LINES=`expr $NB_LINES + $NB_LINES_T`
if [ "$NB_LINES" -gt 0 ]
then
        echo "ERROR: $NB_LINES old lines found in u_fecd file"
        RESEXE=1
fi


# Check in fecl
NB_LINES=0
NB_LINES_T=`cat $FILE_CL | grep -av $DAT_TODAY | grep -a $DAT_THISYEAR | wc -l`
NB_LINES=`expr $NB_LINES + $NB_LINES_T`
NB_LINES_T=`cat $FILE_CL | grep -av $DAT_TODAY | grep -a $DAT_LASTYEAR | wc -l`
NB_LINES=`expr $NB_LINES + $NB_LINES_T`
if [ "$NB_LINES" -gt 0 ]
then
        echo "ERROR: $NB_LINES old lines found in u_fecl file"
        RESEXE=1
fi




#######################################################################
# End

# Finish with advice if error found
if [ "$RESEXE" -gt 0 ]
then
    echo "Advice: Check the Distribution Exchange and Job Exchange"
        
# Message if no error found
else
    echo "Success: No old entry found"
fi

# Return code
exit $RESEXE
